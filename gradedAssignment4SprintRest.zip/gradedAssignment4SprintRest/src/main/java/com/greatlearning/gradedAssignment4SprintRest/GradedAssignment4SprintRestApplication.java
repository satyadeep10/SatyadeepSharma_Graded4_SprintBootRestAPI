package com.greatlearning.gradedAssignment4SprintRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GradedAssignment4SprintRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(GradedAssignment4SprintRestApplication.class, args);
	}

}
