package com.greatlearning.gradedAssignment4SprintRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GradedAssignment4SprintRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
